/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.jmildner.tools;

/**
 *
 * @author johann
 */
public class AgileTest
{
  
    public int add(String s1, String s2)
    {
        int i1 = Integer.parseInt(s1);
        int i2 = Integer.parseInt(s2);
        return i1 + i2;
    }
}
